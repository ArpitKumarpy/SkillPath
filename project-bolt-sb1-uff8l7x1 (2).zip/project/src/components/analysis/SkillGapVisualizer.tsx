import React from 'react';
import { SkillGap, SkillStrength } from '../../services/skillMatcher';

interface SkillGapVisualizerProps {
  strengths: SkillStrength[];
  gaps: SkillGap[];
  missing: {
    name: string;
    category: string;
    requiredLevel: number;
  }[];
}

export const SkillGapVisualizer: React.FC<SkillGapVisualizerProps> = ({
  strengths,
  gaps,
  missing
}) => {
  // Group skills by category
  const groupedStrengths = strengths.reduce((acc, skill) => {
    if (!acc[skill.category]) {
      acc[skill.category] = [];
    }
    acc[skill.category].push(skill);
    return acc;
  }, {} as Record<string, SkillStrength[]>);

  const groupedGaps = gaps.reduce((acc, skill) => {
    if (!acc[skill.category]) {
      acc[skill.category] = [];
    }
    acc[skill.category].push(skill);
    return acc;
  }, {} as Record<string, SkillGap[]>);

  const groupedMissing = missing.reduce((acc, skill) => {
    if (!acc[skill.category]) {
      acc[skill.category] = [];
    }
    acc[skill.category].push(skill);
    return acc;
  }, {} as Record<string, typeof missing>);

  // Get all categories
  const allCategories = [...new Set([
    ...Object.keys(groupedStrengths),
    ...Object.keys(groupedGaps),
    ...Object.keys(groupedMissing)
  ])];

  return (
    <div className="space-y-8">
      {allCategories.map(category => (
        <div key={category} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">{category} Skills</h3>
          
          {/* Strengths */}
          {groupedStrengths[category] && groupedStrengths[category].length > 0 && (
            <div className="mb-6">
              <h4 className="text-lg font-medium text-green-700 mb-3">Strengths</h4>
              <div className="space-y-4">
                {groupedStrengths[category].map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-gray-700">{skill.name}</span>
                      <span className="text-sm font-medium text-gray-700">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div 
                        className="bg-green-500 h-2.5 rounded-full" 
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Gaps */}
          {groupedGaps[category] && groupedGaps[category].length > 0 && (
            <div className="mb-6">
              <h4 className="text-lg font-medium text-amber-700 mb-3">Gaps</h4>
              <div className="space-y-4">
                {groupedGaps[category].map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-gray-700">{skill.name}</span>
                      <span className="text-sm font-medium text-gray-700">
                        {skill.currentLevel}% <span className="text-gray-400">/ {skill.requiredLevel}% needed</span>
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5 relative">
                      <div 
                        className="bg-amber-500 h-2.5 rounded-full" 
                        style={{ width: `${skill.currentLevel}%` }}
                      ></div>
                      <div 
                        className="absolute top-0 h-full border-r-2 border-dashed border-indigo-600" 
                        style={{ left: `${skill.requiredLevel}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Missing */}
          {groupedMissing[category] && groupedMissing[category].length > 0 && (
            <div>
              <h4 className="text-lg font-medium text-red-700 mb-3">Missing</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {groupedMissing[category].map((skill, index) => (
                  <div key={index} className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-gray-800">{skill.name}</span>
                      <span className="text-sm text-gray-500">{skill.requiredLevel}% needed</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};