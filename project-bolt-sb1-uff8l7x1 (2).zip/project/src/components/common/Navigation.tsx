import React from 'react';
import { BookOpen } from 'lucide-react';

interface NavigationProps {
  currentPage: string;
  onNavigate: (page: any) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ 
  currentPage,
  onNavigate
}) => {
  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <BookOpen className="h-8 w-8 text-indigo-600" />
          <span 
            className="ml-2 text-xl font-bold text-gray-800 cursor-pointer"
            onClick={() => onNavigate('home')}
          >
            SkillPath
          </span>
        </div>
        
        <nav>
          <ul className="flex space-x-6 items-center">
            <li>
              <button 
                onClick={() => onNavigate('home')}
                className={`text-sm font-medium ${
                  currentPage === 'home' ? 'text-indigo-600' : 'text-gray-600 hover:text-indigo-600'
                }`}
              >
                Home
              </button>
            </li>
            <li>
              <button 
                onClick={() => onNavigate('profile')}
                className={`text-sm font-medium ${
                  currentPage === 'profile' ? 'text-indigo-600' : 'text-gray-600 hover:text-indigo-600'
                }`}
              >
                Profile
              </button>
            </li>
            <li>
              <button 
                onClick={() => onNavigate('analysis')}
                className={`text-sm font-medium ${
                  currentPage === 'analysis' ? 'text-indigo-600' : 'text-gray-600 hover:text-indigo-600'
                }`}
              >
                Analysis
              </button>
            </li>
            <li>
              <button 
                onClick={() => onNavigate('recommendations')}
                className={`text-sm font-medium ${
                  currentPage === 'recommendations' ? 'text-indigo-600' : 'text-gray-600 hover:text-indigo-600'
                }`}
              >
                Recommendations
              </button>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};