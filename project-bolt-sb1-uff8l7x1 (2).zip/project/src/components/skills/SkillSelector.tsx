import React from 'react';
import { CheckCircle2, Circle } from 'lucide-react';

interface SkillSelectorProps {
  categoryName: string;
  skills: string[];
  selectedSkills: string[];
  onToggleSkill: (skill: string) => void;
}

export const SkillSelector: React.FC<SkillSelectorProps> = ({
  categoryName,
  skills,
  selectedSkills,
  onToggleSkill
}) => {
  return (
    <div className="mb-6">
      <h3 className="text-lg font-medium text-gray-800 mb-3">{categoryName}</h3>
      <div className="flex flex-wrap gap-2">
        {skills.map((skill, index) => (
          <button
            key={index}
            className={`flex items-center px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              selectedSkills.includes(skill)
                ? 'bg-indigo-100 text-indigo-800 border border-indigo-300'
                : 'bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200'
            }`}
            onClick={() => onToggleSkill(skill)}
          >
            {selectedSkills.includes(skill) ? (
              <CheckCircle2 className="mr-1 h-4 w-4 text-indigo-600" />
            ) : (
              <Circle className="mr-1 h-4 w-4 text-gray-400" />
            )}
            {skill}
          </button>
        ))}
      </div>
    </div>
  );
};