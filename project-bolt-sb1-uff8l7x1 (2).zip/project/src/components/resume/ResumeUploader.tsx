import React, { useState } from 'react';
import { Upload, FileText, Loader } from 'lucide-react';
import { parseResume, ParsedResume } from '../../services/resumeParser';

interface ResumeUploaderProps {
  onResumeProcessed: (resumeData: ParsedResume) => void;
}

export const ResumeUploader: React.FC<ResumeUploaderProps> = ({ onResumeProcessed }) => {
  const [file, setFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [processingStage, setProcessingStage] = useState<string>('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      
      // Check file type
      if (
        selectedFile.type !== 'application/pdf' && 
        selectedFile.type !== 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      ) {
        setError('Please upload a PDF or Word document');
        return;
      }
      
      setFile(selectedFile);
      setError(null);
    }
  };

  const handleUpload = async () => {
    if (!file) {
      setError('Please select a file first');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      // Show processing stages to improve user experience
      setProcessingStage('Extracting text from document...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setProcessingStage('Analyzing content with NLP...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setProcessingStage('Identifying skills and experience...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setProcessingStage('Categorizing skills...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setProcessingStage('Finalizing analysis...');
      const resumeData = await parseResume(file);
      onResumeProcessed(resumeData);
    } catch (err) {
      setError('Failed to process resume. Please try again.');
      console.error('Resume parsing error:', err);
    } finally {
      setIsProcessing(false);
      setProcessingStage('');
    }
  };

  return (
    <div className="w-full">
      <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
        <div className="flex flex-col items-center">
          {isProcessing ? (
            <>
              <Loader className="h-12 w-12 text-indigo-500 animate-spin mb-4" />
              <p className="text-gray-600 mb-2">Processing your resume with AI...</p>
              <p className="text-sm text-indigo-500 font-medium mb-2">{processingStage}</p>
              <div className="w-64 bg-gray-200 rounded-full h-2 mb-4">
                <div className="bg-indigo-600 h-2 rounded-full animate-pulse" style={{ width: '100%' }}></div>
              </div>
              <p className="text-sm text-gray-500">This may take a moment as we extract and analyze your skills.</p>
            </>
          ) : (
            <>
              <Upload className="h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-600 mb-2">Drag and drop your resume here, or</p>
              <label className="cursor-pointer bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors">
                Browse Files
                <input 
                  type="file" 
                  className="hidden" 
                  accept=".pdf,.doc,.docx" 
                  onChange={handleFileChange}
                />
              </label>
              {file && (
                <div className="mt-4 flex items-center">
                  <FileText className="text-indigo-500 mr-2" size={20} />
                  <span className="text-gray-700">{file.name}</span>
                </div>
              )}
              {error && (
                <p className="mt-2 text-red-500 text-sm">{error}</p>
              )}
              {file && !error && (
                <button
                  onClick={handleUpload}
                  className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors"
                >
                  Process Resume
                </button>
              )}
            </>
          )}
        </div>
      </div>
      <div className="mt-4 text-sm text-gray-500">
        <p>Our AI will analyze your resume to:</p>
        <ul className="list-disc list-inside mt-2">
          <li>Extract your technical, soft, and professional skills using NLP</li>
          <li>Identify your experience level in each skill based on context</li>
          <li>Compare your profile with your target role requirements</li>
          <li>Generate personalized course recommendations to bridge skill gaps</li>
        </ul>
      </div>
    </div>
  );
};