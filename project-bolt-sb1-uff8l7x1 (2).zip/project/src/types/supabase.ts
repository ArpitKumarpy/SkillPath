export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          created_at: string
          email: string
          full_name: string | null
          resume_text: string | null
          linkedin_url: string | null
          target_role: string | null
        }
        Insert: {
          id: string
          created_at?: string
          email: string
          full_name?: string | null
          resume_text?: string | null
          linkedin_url?: string | null
          target_role?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          email?: string
          full_name?: string | null
          resume_text?: string | null
          linkedin_url?: string | null
          target_role?: string | null
        }
      }
      skills: {
        Row: {
          id: string
          created_at: string
          profile_id: string
          name: string
          category: string
          level: number
        }
        Insert: {
          id?: string
          created_at?: string
          profile_id: string
          name: string
          category: string
          level: number
        }
        Update: {
          id?: string
          created_at?: string
          profile_id?: string
          name?: string
          category?: string
          level?: number
        }
      }
      job_roles: {
        Row: {
          id: string
          created_at: string
          title: string
          description: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          title: string
          description?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          title?: string
          description?: string | null
        }
      }
      role_skills: {
        Row: {
          id: string
          created_at: string
          role_id: string
          skill_name: string
          category: string
          required_level: number
        }
        Insert: {
          id?: string
          created_at?: string
          role_id: string
          skill_name: string
          category: string
          required_level: number
        }
        Update: {
          id?: string
          created_at?: string
          role_id?: string
          skill_name?: string
          category?: string
          required_level?: number
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}