import React, { useState } from 'react';
import { Home } from './pages/Home';
import { ProfileInput } from './pages/ProfileInput';
import { SkillAnalysis } from './pages/SkillAnalysis';
import { Recommendations } from './pages/Recommendations';
import { Navigation } from './components/common/Navigation';
import { Footer } from './components/common/Footer';

type Page = 'home' | 'profile' | 'analysis' | 'recommendations';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home onGetStarted={() => setCurrentPage('profile')} />;
      case 'profile':
        return <ProfileInput onComplete={() => setCurrentPage('analysis')} />;
      case 'analysis':
        return <SkillAnalysis onViewRecommendations={() => setCurrentPage('recommendations')} />;
      case 'recommendations':
        return <Recommendations />;
      default:
        return <Home onGetStarted={() => setCurrentPage('profile')} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navigation 
        currentPage={currentPage}
        onNavigate={setCurrentPage}
      />
      <main className="flex-grow">
        {renderPage()}
      </main>
      <Footer />
    </div>
  );
}

export default App;