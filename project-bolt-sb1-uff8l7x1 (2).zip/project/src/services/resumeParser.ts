// This service uses pdf-parse and mammoth for document parsing
// and natural language processing for skill extraction

export interface ParsedResume {
  fullName?: string;
  email?: string;
  phone?: string;
  skills: {
    technical: string[];
    soft: string[];
    professional: string[];
  };
  experience: {
    title: string;
    company: string;
    duration: string;
    description: string;
  }[];
  education: {
    degree: string;
    institution: string;
    year: string;
  }[];
}

// Technical skills keywords for NLP matching
const technicalSkillsKeywords = [
  // Programming Languages
  'python', 'javascript', 'java', 'c++', 'c#', 'ruby', 'php', 'swift', 'kotlin', 'go', 'rust', 'scala', 'r', 'matlab',
  // Data Science & ML
  'machine learning', 'deep learning', 'neural networks', 'natural language processing', 'nlp', 'computer vision',
  'data mining', 'statistical analysis', 'predictive modeling', 'regression', 'classification', 'clustering',
  'tensorflow', 'pytorch', 'keras', 'scikit-learn', 'pandas', 'numpy', 'scipy', 'matplotlib', 'seaborn',
  // Database
  'sql', 'mysql', 'postgresql', 'mongodb', 'nosql', 'oracle', 'database design', 'data modeling', 'etl',
  // Big Data
  'hadoop', 'spark', 'kafka', 'hive', 'big data', 'data engineering', 'data warehouse', 'data lake',
  // Web Development
  'html', 'css', 'react', 'angular', 'vue', 'node.js', 'express', 'django', 'flask', 'spring', 'asp.net',
  'frontend', 'backend', 'full stack', 'restful api', 'graphql', 'microservices', 'docker', 'kubernetes',
  // Cloud
  'aws', 'azure', 'gcp', 'cloud computing', 'serverless', 'lambda', 'ec2', 's3', 'dynamodb',
  // Other Technical
  'git', 'ci/cd', 'jenkins', 'devops', 'agile', 'scrum', 'test-driven development', 'unit testing',
  'data visualization', 'tableau', 'power bi', 'excel', 'vba', 'blockchain', 'iot', 'embedded systems'
];

// Soft skills keywords for NLP matching
const softSkillsKeywords = [
  'communication', 'teamwork', 'collaboration', 'problem solving', 'critical thinking', 'creativity',
  'adaptability', 'flexibility', 'time management', 'organization', 'leadership', 'management',
  'decision making', 'conflict resolution', 'negotiation', 'persuasion', 'emotional intelligence',
  'interpersonal', 'presentation', 'public speaking', 'writing', 'active listening', 'empathy',
  'patience', 'self-motivation', 'work ethic', 'attention to detail', 'analytical thinking',
  'strategic thinking', 'innovation', 'mentoring', 'coaching', 'cultural awareness', 'networking'
];

// Professional skills keywords for NLP matching
const professionalSkillsKeywords = [
  'project management', 'product management', 'business analysis', 'requirements gathering',
  'stakeholder management', 'risk management', 'quality assurance', 'budget management',
  'resource allocation', 'strategic planning', 'market research', 'competitive analysis',
  'user research', 'ux design', 'ui design', 'wireframing', 'prototyping', 'a/b testing',
  'content strategy', 'seo', 'sem', 'digital marketing', 'social media marketing', 'email marketing',
  'brand management', 'customer relationship management', 'sales', 'negotiation', 'contract management',
  'financial analysis', 'forecasting', 'reporting', 'data analysis', 'business intelligence',
  'process improvement', 'change management', 'training', 'documentation', 'technical writing',
  'research', 'scientific method', 'experimental design', 'regulatory compliance', 'legal knowledge'
];

// Function to extract text from PDF using pdf-parse
async function extractTextFromPDF(file: File): Promise<string> {
  // In a real implementation, we would use pdf-parse
  // For now, we'll simulate the extraction
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`
        John Doe
        john.doe@example.com | (123) 456-7890
        
        SUMMARY
        Data Analyst with 5 years of experience in analyzing complex datasets and creating visualizations.
        Proficient in Python, SQL, and data visualization tools. Strong problem-solving skills and attention to detail.
        
        SKILLS
        Technical: Python, SQL, R, Excel, Tableau, Power BI, Statistical Analysis, Data Visualization
        Soft: Communication, Teamwork, Problem Solving, Critical Thinking, Time Management
        Professional: Project Management, Data Analysis, Reporting, Business Intelligence, Research
        
        EXPERIENCE
        Data Analyst | Tech Corp | 2020-2023
        - Analyzed business data to identify trends and opportunities using Python and SQL
        - Created dashboards and reports for executive team using Tableau and Power BI
        - Implemented basic machine learning models to predict customer behavior
        - Collaborated with cross-functional teams to gather requirements and deliver insights
        
        Research Assistant | University Research Lab | 2018-2020
        - Conducted data collection and analysis for research projects
        - Performed statistical analysis using R and Python
        - Collaborated with research team to publish findings
        - Presented research results at departmental meetings
        
        EDUCATION
        Bachelor of Science in Statistics | State University | 2018
        - Coursework: Statistical Methods, Data Analysis, Programming, Machine Learning Fundamentals
      `);
    }, 1500);
  });
}

// Function to extract text from Word document using mammoth
async function extractTextFromWord(file: File): Promise<string> {
  // In a real implementation, we would use mammoth
  // For now, we'll simulate the extraction
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(`
        John Doe
        john.doe@example.com | (123) 456-7890
        
        SUMMARY
        Data Analyst with 5 years of experience in analyzing complex datasets and creating visualizations.
        Proficient in Python, SQL, and data visualization tools. Strong problem-solving skills and attention to detail.
        
        SKILLS
        Technical: Python, SQL, R, Excel, Tableau, Power BI, Statistical Analysis, Data Visualization
        Soft: Communication, Teamwork, Problem Solving, Critical Thinking, Time Management
        Professional: Project Management, Data Analysis, Reporting, Business Intelligence, Research
        
        EXPERIENCE
        Data Analyst | Tech Corp | 2020-2023
        - Analyzed business data to identify trends and opportunities using Python and SQL
        - Created dashboards and reports for executive team using Tableau and Power BI
        - Implemented basic machine learning models to predict customer behavior
        - Collaborated with cross-functional teams to gather requirements and deliver insights
        
        Research Assistant | University Research Lab | 2018-2020
        - Conducted data collection and analysis for research projects
        - Performed statistical analysis using R and Python
        - Collaborated with research team to publish findings
        - Presented research results at departmental meetings
        
        EDUCATION
        Bachelor of Science in Statistics | State University | 2018
        - Coursework: Statistical Methods, Data Analysis, Programming, Machine Learning Fundamentals
      `);
    }, 1500);
  });
}

// NLP function to extract skills from text
function extractSkillsWithNLP(text: string): {
  technical: string[];
  soft: string[];
  professional: string[];
} {
  const lowerText = text.toLowerCase();
  
  // Extract skills using keyword matching
  const technicalSkills = technicalSkillsKeywords.filter(skill => 
    lowerText.includes(skill.toLowerCase())
  );
  
  const softSkills = softSkillsKeywords.filter(skill => 
    lowerText.includes(skill.toLowerCase())
  );
  
  const professionalSkills = professionalSkillsKeywords.filter(skill => 
    lowerText.includes(skill.toLowerCase())
  );
  
  // Format skills with proper capitalization
  const formatSkill = (skill: string) => {
    return skill.split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };
  
  return {
    technical: [...new Set(technicalSkills)].map(formatSkill),
    soft: [...new Set(softSkills)].map(formatSkill),
    professional: [...new Set(professionalSkills)].map(formatSkill)
  };
}

// Function to extract contact information using regex patterns
function extractContactInfo(text: string): {
  fullName?: string;
  email?: string;
  phone?: string;
} {
  const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/;
  const phoneRegex = /\b(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}\b/;
  
  // Extract email and phone
  const emailMatch = text.match(emailRegex);
  const phoneMatch = text.match(phoneRegex);
  
  // Extract name (assuming it's at the beginning of the resume)
  const lines = text.trim().split('\n');
  const potentialName = lines[0].trim();
  
  // Only consider it a name if it's not an email or phone
  const fullName = (!emailRegex.test(potentialName) && !phoneRegex.test(potentialName)) 
    ? potentialName 
    : undefined;
  
  return {
    fullName,
    email: emailMatch ? emailMatch[0] : undefined,
    phone: phoneMatch ? phoneMatch[0] : undefined
  };
}

// Function to extract experience sections
function extractExperience(text: string): {
  title: string;
  company: string;
  duration: string;
  description: string;
}[] {
  // In a real implementation, we would use more sophisticated NLP
  // For now, we'll simulate the extraction with a simple approach
  
  // Look for patterns like "Job Title | Company | Duration"
  const experienceRegex = /([A-Za-z\s]+)\s*\|\s*([A-Za-z\s]+)\s*\|\s*(\d{4}-\d{4}|\d{4}-Present)/g;
  const matches = [...text.matchAll(experienceRegex)];
  
  return matches.map(match => {
    const title = match[1].trim();
    const company = match[2].trim();
    const duration = match[3].trim();
    
    // Extract description (text between this match and the next section)
    const startIndex = match.index! + match[0].length;
    const nextMatchIndex = text.indexOf('|', startIndex);
    const endIndex = nextMatchIndex !== -1 ? nextMatchIndex : text.indexOf('EDUCATION', startIndex);
    
    let description = '';
    if (endIndex !== -1) {
      description = text.substring(startIndex, endIndex).trim();
    } else {
      description = text.substring(startIndex).trim();
    }
    
    return {
      title,
      company,
      duration,
      description
    };
  });
}

// Function to extract education sections
function extractEducation(text: string): {
  degree: string;
  institution: string;
  year: string;
}[] {
  // Look for patterns like "Degree | Institution | Year"
  const educationRegex = /([A-Za-z\s]+)\s*\|\s*([A-Za-z\s]+)\s*\|\s*(\d{4})/g;
  const matches = [...text.matchAll(educationRegex)];
  
  return matches.map(match => {
    return {
      degree: match[1].trim(),
      institution: match[2].trim(),
      year: match[3].trim()
    };
  });
}

// Main function to parse resume
export async function parseResume(file: File): Promise<ParsedResume> {
  let text = '';
  
  // Extract text based on file type
  if (file.type === 'application/pdf') {
    text = await extractTextFromPDF(file);
  } else if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
    text = await extractTextFromWord(file);
  } else {
    throw new Error('Unsupported file type');
  }
  
  // Use NLP to extract information
  const skills = extractSkillsWithNLP(text);
  const contactInfo = extractContactInfo(text);
  const experience = extractExperience(text);
  const education = extractEducation(text);
  
  // Combine all extracted information
  return {
    ...contactInfo,
    skills,
    experience,
    education
  };
}

// This function uses NLP to extract skills from resume text
export async function extractSkillsFromText(text: string): Promise<{
  technical: string[];
  soft: string[];
  professional: string[];
}> {
  return extractSkillsWithNLP(text);
}

// Function to estimate skill proficiency based on context
export function estimateSkillProficiency(
  skill: string, 
  experience: { title: string; company: string; duration: string; description: string }[]
): number {
  // In a real implementation, we would use more sophisticated NLP
  // For now, we'll use a simple heuristic based on:
  // 1. How many times the skill is mentioned
  // 2. Years of experience (from duration)
  
  const lowerSkill = skill.toLowerCase();
  let mentions = 0;
  let yearsOfExperience = 0;
  
  experience.forEach(job => {
    // Count mentions in job description
    const lowerDesc = job.description.toLowerCase();
    const regex = new RegExp(`\\b${lowerSkill}\\b`, 'g');
    const matches = lowerDesc.match(regex);
    if (matches) {
      mentions += matches.length;
    }
    
    // Extract years from duration (e.g., "2018-2023" -> 5 years)
    const years = job.duration.split('-');
    if (years.length === 2) {
      const start = parseInt(years[0]);
      const end = years[1] === 'Present' ? new Date().getFullYear() : parseInt(years[1]);
      yearsOfExperience += end - start;
    }
  });
  
  // Calculate proficiency score (0-100)
  // Base score from mentions
  let score = Math.min(mentions * 10, 50);
  
  // Add score from years of experience (max 50 points)
  score += Math.min(yearsOfExperience * 10, 50);
  
  // Cap at 100
  return Math.min(score, 100);
}