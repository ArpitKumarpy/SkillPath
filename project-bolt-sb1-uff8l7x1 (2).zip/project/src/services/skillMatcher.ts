export interface SkillGap {
  name: string;
  category: string;
  currentLevel: number;
  requiredLevel: number;
  gap: number;
}

export interface SkillStrength {
  name: string;
  category: string;
  level: number;
}

export interface SkillMatch {
  overallMatch: number;
  strengths: SkillStrength[];
  gaps: SkillGap[];
  missing: {
    name: string;
    category: string;
    requiredLevel: number;
  }[];
}

// Define role requirements for different job roles
const roleRequirements: Record<string, {
  skills: {
    name: string;
    category: string;
    requiredLevel: number;
  }[];
}> = {
  'Data Scientist': {
    skills: [
      { name: 'Python', category: 'Technical', requiredLevel: 80 },
      { name: 'Machine Learning', category: 'Technical', requiredLevel: 75 },
      { name: 'Statistics', category: 'Technical', requiredLevel: 85 },
      { name: 'SQL', category: 'Technical', requiredLevel: 70 },
      { name: 'Data Visualization', category: 'Technical', requiredLevel: 75 },
      { name: 'Big Data Technologies', category: 'Technical', requiredLevel: 65 },
      { name: 'Deep Learning', category: 'Technical', requiredLevel: 60 },
      { name: 'Natural Language Processing', category: 'Technical', requiredLevel: 55 },
      { name: 'R', category: 'Technical', requiredLevel: 60 },
      { name: 'Cloud Computing', category: 'Technical', requiredLevel: 65 },
      { name: 'Problem Solving', category: 'Soft', requiredLevel: 90 },
      { name: 'Communication', category: 'Soft', requiredLevel: 80 },
      { name: 'Teamwork', category: 'Soft', requiredLevel: 75 },
      { name: 'Critical Thinking', category: 'Soft', requiredLevel: 85 },
      { name: 'Data Analysis', category: 'Professional', requiredLevel: 90 },
      { name: 'Research', category: 'Professional', requiredLevel: 80 },
      { name: 'Project Management', category: 'Professional', requiredLevel: 60 }
    ]
  },
  'Software Engineer': {
    skills: [
      { name: 'JavaScript', category: 'Technical', requiredLevel: 85 },
      { name: 'React', category: 'Technical', requiredLevel: 80 },
      { name: 'Node.js', category: 'Technical', requiredLevel: 75 },
      { name: 'TypeScript', category: 'Technical', requiredLevel: 70 },
      { name: 'Git', category: 'Technical', requiredLevel: 80 },
      { name: 'SQL', category: 'Technical', requiredLevel: 65 },
      { name: 'Python', category: 'Technical', requiredLevel: 60 },
      { name: 'System Architecture', category: 'Technical', requiredLevel: 65 },
      { name: 'Docker', category: 'Technical', requiredLevel: 60 },
      { name: 'CI/CD', category: 'Technical', requiredLevel: 70 },
      { name: 'Problem Solving', category: 'Soft', requiredLevel: 90 },
      { name: 'Communication', category: 'Soft', requiredLevel: 75 },
      { name: 'Teamwork', category: 'Soft', requiredLevel: 85 },
      { name: 'Time Management', category: 'Soft', requiredLevel: 80 },
      { name: 'Code Review', category: 'Professional', requiredLevel: 80 },
      { name: 'Agile Methodologies', category: 'Professional', requiredLevel: 75 },
      { name: 'Testing', category: 'Professional', requiredLevel: 80 }
    ]
  },
  'Product Manager': {
    skills: [
      { name: 'Market Research', category: 'Professional', requiredLevel: 85 },
      { name: 'Product Strategy', category: 'Professional', requiredLevel: 90 },
      { name: 'User Research', category: 'Professional', requiredLevel: 80 },
      { name: 'Competitive Analysis', category: 'Professional', requiredLevel: 75 },
      { name: 'Roadmapping', category: 'Professional', requiredLevel: 85 },
      { name: 'Agile Methodologies', category: 'Professional', requiredLevel: 80 },
      { name: 'Project Management', category: 'Professional', requiredLevel: 85 },
      { name: 'Data Analysis', category: 'Professional', requiredLevel: 70 },
      { name: 'Communication', category: 'Soft', requiredLevel: 95 },
      { name: 'Leadership', category: 'Soft', requiredLevel: 85 },
      { name: 'Negotiation', category: 'Soft', requiredLevel: 80 },
      { name: 'Problem Solving', category: 'Soft', requiredLevel: 85 },
      { name: 'Strategic Thinking', category: 'Soft', requiredLevel: 90 },
      { name: 'SQL', category: 'Technical', requiredLevel: 50 },
      { name: 'Data Visualization', category: 'Technical', requiredLevel: 60 },
      { name: 'Wireframing', category: 'Technical', requiredLevel: 70 },
      { name: 'Prototyping', category: 'Technical', requiredLevel: 65 }
    ]
  },
  'UX Designer': {
    skills: [
      { name: 'User Research', category: 'Professional', requiredLevel: 90 },
      { name: 'Wireframing', category: 'Technical', requiredLevel: 95 },
      { name: 'Prototyping', category: 'Technical', requiredLevel: 90 },
      { name: 'UI Design', category: 'Technical', requiredLevel: 85 },
      { name: 'Usability Testing', category: 'Professional', requiredLevel: 85 },
      { name: 'Information Architecture', category: 'Professional', requiredLevel: 80 },
      { name: 'Interaction Design', category: 'Professional', requiredLevel: 85 },
      { name: 'Visual Design', category: 'Technical', requiredLevel: 80 },
      { name: 'Design Systems', category: 'Technical', requiredLevel: 75 },
      { name: 'Figma', category: 'Technical', requiredLevel: 85 },
      { name: 'Adobe XD', category: 'Technical', requiredLevel: 75 },
      { name: 'Sketch', category: 'Technical', requiredLevel: 70 },
      { name: 'Communication', category: 'Soft', requiredLevel: 90 },
      { name: 'Empathy', category: 'Soft', requiredLevel: 95 },
      { name: 'Creativity', category: 'Soft', requiredLevel: 90 },
      { name: 'Collaboration', category: 'Soft', requiredLevel: 85 },
      { name: 'Problem Solving', category: 'Soft', requiredLevel: 80 }
    ]
  }
};

// This function analyzes skills and provides a match score
export async function aiSkillAnalysis(
  userSkills: { name: string; level: number }[],
  targetRole: string
): Promise<SkillMatch> {
  // Get requirements for the target role
  const requirements = roleRequirements[targetRole] || roleRequirements['Data Scientist'];
  
  // Create a map of user skills for easy lookup
  const userSkillsMap = new Map(
    userSkills.map(skill => [skill.name.toLowerCase(), skill])
  );
  
  // Identify strengths, gaps, and missing skills
  const strengths: SkillStrength[] = [];
  const gaps: SkillGap[] = [];
  const missing: { name: string; category: string; requiredLevel: number }[] = [];
  
  // Process each required skill
  requirements.skills.forEach(requiredSkill => {
    const userSkill = userSkillsMap.get(requiredSkill.name.toLowerCase());
    
    if (userSkill) {
      // User has this skill
      if (userSkill.level >= requiredSkill.requiredLevel) {
        // It's a strength
        strengths.push({
          name: requiredSkill.name,
          category: requiredSkill.category,
          level: userSkill.level
        });
      } else {
        // It's a gap
        gaps.push({
          name: requiredSkill.name,
          category: requiredSkill.category,
          currentLevel: userSkill.level,
          requiredLevel: requiredSkill.requiredLevel,
          gap: requiredSkill.requiredLevel - userSkill.level
        });
      }
    } else {
      // User is missing this skill
      missing.push({
        name: requiredSkill.name,
        category: requiredSkill.category,
        requiredLevel: requiredSkill.requiredLevel
      });
    }
  });
  
  // Calculate overall match score
  const totalRequiredPoints = requirements.skills.reduce(
    (sum, skill) => sum + skill.requiredLevel, 
    0
  );
  
  // Calculate points from user's skills
  let userPoints = 0;
  
  // Points from strengths (full points)
  userPoints += strengths.reduce(
    (sum, strength) => {
      const requiredSkill = requirements.skills.find(s => s.name === strength.name);
      return sum + (requiredSkill ? requiredSkill.requiredLevel : 0);
    }, 
    0
  );
  
  // Points from gaps (partial points)
  userPoints += gaps.reduce(
    (sum, gap) => sum + gap.currentLevel,
    0
  );
  
  // Calculate match percentage
  const overallMatch = Math.round((userPoints / totalRequiredPoints) * 100);
  
  // Sort results by relevance
  strengths.sort((a, b) => b.level - a.level);
  gaps.sort((a, b) => b.gap - a.gap);
  missing.sort((a, b) => b.requiredLevel - a.requiredLevel);
  
  return {
    overallMatch,
    strengths,
    gaps,
    missing
  };
}

// Function to get recommended courses based on skill gaps and missing skills
export function getRecommendedCourses(
  skillMatch: SkillMatch,
  targetRole: string
): any[] {
  // Define course database with skill mappings
  const courseDatabase = [
    {
      id: 1,
      title: "Machine Learning A-Z: Hands-On Python & R",
      provider: "Udemy",
      instructor: "Kirill Eremenko, Hadelin de Ponteves",
      rating: 4.7,
      reviews: 156789,
      duration: "42.5 hours",
      level: "Beginner to Intermediate",
      price: 94.99,
      discount: true,
      discountPrice: 13.99,
      image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1169&q=80",
      category: "machine-learning",
      skills: ["Machine Learning", "Python", "R", "Data Science"],
      matchScore: 95,
      roles: ["Data Scientist"]
    },
    {
      id: 2,
      title: "Statistics for Data Science and Business Analysis",
      provider: "Udemy",
      instructor: "365 Careers",
      rating: 4.5,
      reviews: 32456,
      duration: "5.5 hours",
      level: "Beginner",
      price: 84.99,
      discount: true,
      discountPrice: 11.99,
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
      category: "statistics",
      skills: ["Statistics", "Data Science", "Business Analysis"],
      matchScore: 90,
      roles: ["Data Scientist", "Product Manager"]
    },
    {
      id: 3,
      title: "Data Visualization with Python: Matplotlib & Seaborn",
      provider: "Coursera",
      instructor: "IBM",
      rating: 4.6,
      reviews: 12345,
      duration: "16 hours",
      level: "Intermediate",
      price: 49,
      discount: false,
      discountPrice: null,
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
      category: "data-visualization",
      skills: ["Data Visualization", "Python", "Matplotlib", "Seaborn"],
      matchScore: 85,
      roles: ["Data Scientist", "Product Manager"]
    },
    {
      id: 4,
      title: "Big Data with Apache Spark and Hadoop",
      provider: "edX",
      instructor: "UC San Diego",
      rating: 4.4,
      reviews: 8765,
      duration: "32 hours",
      level: "Advanced",
      price: 199,
      discount: true,
      discountPrice: 149,
      image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1034&q=80",
      category: "big-data",
      skills: ["Big Data", "Apache Spark", "Hadoop", "Data Engineering"],
      matchScore: 80,
      roles: ["Data Scientist"]
    },
    {
      id: 5,
      title: "Deep Learning Specialization",
      provider: "Coursera",
      instructor: "Andrew Ng, DeepLearning.AI",
      rating: 4.9,
      reviews: 98765,
      duration: "80 hours",
      level: "Intermediate to Advanced",
      price: 49,
      discount: false,
      discountPrice: null,
      image: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=765&q=80",
      category: "deep-learning",
      skills: ["Deep Learning", "Neural Networks", "Machine Learning", "Python"],
      matchScore: 75,
      roles: ["Data Scientist"]
    },
    {
      id: 6,
      title: "AWS Certified Data Analytics",
      provider: "LinkedIn Learning",
      instructor: "Lynn Langit",
      rating: 4.7,
      reviews: 5432,
      duration: "24 hours",
      level: "Intermediate",
      price: 29.99,
      discount: false,
      discountPrice: null,
      image: "https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
      category: "cloud-computing",
      skills: ["AWS", "Cloud Computing", "Data Analytics", "Big Data"],
      matchScore: 70,
      roles: ["Data Scientist"]
    },
    {
      id: 7,
      title: "The Complete JavaScript Course",
      provider: "Udemy",
      instructor: "Jonas Schmedtmann",
      rating: 4.8,
      reviews: 125000,
      duration: "69 hours",
      level: "Beginner to Advanced",
      price: 89.99,
      discount: true,
      discountPrice: 14.99,
      image: "https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
      category: "javascript",
      skills: ["JavaScript", "Web Development", "ES6"],
      matchScore: 95,
      roles: ["Software Engineer"]
    },
    {
      id: 8,
      title: "React - The Complete Guide",
      provider: "Udemy",
      instructor: "Maximilian Schwarzmüller",
      rating: 4.7,
      reviews: 145000,
      duration: "48 hours",
      level: "Beginner to Advanced",
      price: 89.99,
      discount: true,
      discountPrice: 14.99,
      image: "https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
      category: "react",
      skills: ["React", "JavaScript", "Web Development"],
      matchScore: 90,
      roles: ["Software Engineer"]
    },
    {
      id: 9,
      title: "Product Management: Skills for Product Managers",
      provider: "Coursera",
      instructor: "University of Virginia",
      rating: 4.6,
      reviews: 8500,
      duration: "20 hours",
      level: "Intermediate",
      price: 49,
      discount: false,
      discountPrice: null,
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1115&q=80",
      category: "product-management",
      skills: ["Product Strategy", "Market Research", "Roadmapping"],
      matchScore: 95,
      roles: ["Product Manager"]
    },
    {
      id: 10,
      title: "UI/UX Design Specialization",
      provider: "Coursera",
      instructor: "California Institute of the Arts",
      rating: 4.7,
      reviews: 12500,
      duration: "40 hours",
      level: "Beginner to Intermediate",
      price: 49,
      discount: false,
      discountPrice: null,
      image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1064&q=80",
      category: "ux-design",
      skills: ["UI Design", "UX Design", "Wireframing", "Prototyping"],
      matchScore: 90,
      roles: ["UX Designer"]
    }
  ];
  
  // Get all skill gaps and missing skills
  const skillsToImprove = [
    ...skillMatch.gaps.map(gap => gap.name),
    ...skillMatch.missing.map(skill => skill.name)
  ];
  
  // Filter courses that are relevant to the target role and address skill gaps
  const relevantCourses = courseDatabase.filter(course => {
    // Check if course is relevant for the target role
    if (!course.roles.includes(targetRole)) {
      return false;
    }
    
    // Check if course addresses at least one skill gap
    return course.skills.some(skill => 
      skillsToImprove.includes(skill) || 
      skillsToImprove.some(s => skill.includes(s) || s.includes(skill))
    );
  });
  
  // Calculate custom match score based on how many skill gaps the course addresses
  const coursesWithCustomScore = relevantCourses.map(course => {
    // Count how many skill gaps this course addresses
    const addressedSkills = skillsToImprove.filter(skill => 
      course.skills.includes(skill) || 
      course.skills.some(s => s.includes(skill) || skill.includes(s))
    );
    
    // Calculate custom match score (higher if addresses more critical gaps)
    const customScore = addressedSkills.reduce((score, skill) => {
      const gap = skillMatch.gaps.find(g => g.name === skill);
      const missing = skillMatch.missing.find(m => m.name === skill);
      
      // Add more points for bigger gaps and missing skills
      if (gap) {
        return score + gap.gap;
      } else if (missing) {
        return score + missing.requiredLevel;
      }
      return score + 10; // Default value
    }, 0);
    
    return {
      ...course,
      customMatchScore: customScore
    };
  });
  
  // Sort by custom match score (descending)
  return coursesWithCustomScore
    .sort((a, b) => b.customMatchScore - a.customMatchScore);
}