import React, { useState } from 'react';
import { Linkedin, ChevronRight, ChevronLeft, Plus } from 'lucide-react';
import { ResumeUploader } from '../components/resume/ResumeUploader';
import { SkillSelector } from '../components/skills/SkillSelector';
import { ParsedResume } from '../services/resumeParser';

interface ProfileInputProps {
  onComplete: () => void;
}

export const ProfileInput: React.FC<ProfileInputProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [linkedinUrl, setLinkedinUrl] = useState('');
  const [parsedResume, setParsedResume] = useState<ParsedResume | null>(null);
  
  const [technicalSkills, setTechnicalSkills] = useState<string[]>([]);
  const [softSkills, setSoftSkills] = useState<string[]>([]);
  const [professionalSkills, setProfessionalSkills] = useState<string[]>([]);
  
  const [selectedTechnicalSkills, setSelectedTechnicalSkills] = useState<string[]>([]);
  const [selectedSoftSkills, setSelectedSoftSkills] = useState<string[]>([]);
  const [selectedProfessionalSkills, setSelectedProfessionalSkills] = useState<string[]>([]);
  
  const [newSkill, setNewSkill] = useState('');
  const [newSkillCategory, setNewSkillCategory] = useState('technical');
  
  const [targetRole, setTargetRole] = useState('');
  const [experienceLevel, setExperienceLevel] = useState('Mid Level');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sample job roles
  const jobRoles = [
    'Data Scientist',
    'Software Engineer',
    'Product Manager',
    'UX Designer',
    'Marketing Manager',
    'Sales Representative',
    'Project Manager',
    'Business Analyst'
  ];

  const handleResumeProcessed = (resumeData: ParsedResume) => {
    setParsedResume(resumeData);
    
    // Set extracted skills
    setTechnicalSkills(resumeData.skills.technical);
    setSoftSkills(resumeData.skills.soft);
    setProfessionalSkills(resumeData.skills.professional);
    
    // Pre-select all extracted skills
    setSelectedTechnicalSkills([...resumeData.skills.technical]);
    setSelectedSoftSkills([...resumeData.skills.soft]);
    setSelectedProfessionalSkills([...resumeData.skills.professional]);
    
    // Move to next step
    setStep(2);
  };

  const toggleTechnicalSkill = (skill: string) => {
    if (selectedTechnicalSkills.includes(skill)) {
      setSelectedTechnicalSkills(selectedTechnicalSkills.filter(s => s !== skill));
    } else {
      setSelectedTechnicalSkills([...selectedTechnicalSkills, skill]);
    }
  };

  const toggleSoftSkill = (skill: string) => {
    if (selectedSoftSkills.includes(skill)) {
      setSelectedSoftSkills(selectedSoftSkills.filter(s => s !== skill));
    } else {
      setSelectedSoftSkills([...selectedSoftSkills, skill]);
    }
  };

  const toggleProfessionalSkill = (skill: string) => {
    if (selectedProfessionalSkills.includes(skill)) {
      setSelectedProfessionalSkills(selectedProfessionalSkills.filter(s => s !== skill));
    } else {
      setSelectedProfessionalSkills([...selectedProfessionalSkills, skill]);
    }
  };

  const handleAddCustomSkill = () => {
    if (!newSkill.trim()) return;
    
    switch (newSkillCategory) {
      case 'technical':
        if (!technicalSkills.includes(newSkill)) {
          setTechnicalSkills([...technicalSkills, newSkill]);
          setSelectedTechnicalSkills([...selectedTechnicalSkills, newSkill]);
        }
        break;
      case 'soft':
        if (!softSkills.includes(newSkill)) {
          setSoftSkills([...softSkills, newSkill]);
          setSelectedSoftSkills([...selectedSoftSkills, newSkill]);
        }
        break;
      case 'professional':
        if (!professionalSkills.includes(newSkill)) {
          setProfessionalSkills([...professionalSkills, newSkill]);
          setSelectedProfessionalSkills([...selectedProfessionalSkills, newSkill]);
        }
        break;
    }
    
    setNewSkill('');
  };

  const handleNext = async () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      // Submit profile data
      setIsSubmitting(true);
      
      try {
        // In a real app, we would save to a database
        // For now, we'll just simulate the API call with a timeout
        setTimeout(() => {
          // Store the selected skills and target role in localStorage for use in other components
          localStorage.setItem('userSkills', JSON.stringify({
            technical: selectedTechnicalSkills,
            soft: selectedSoftSkills,
            professional: selectedProfessionalSkills,
            targetRole: targetRole,
            experienceLevel: experienceLevel
          }));
          
          // Complete the profile setup
          onComplete();
        }, 1500);
      } catch (error) {
        console.error('Error saving profile:', error);
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-gray-800">Complete Your Profile</h1>
            <div className="text-sm text-gray-500">Step {step} of 3</div>
          </div>
          
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-indigo-600 h-2.5 rounded-full transition-all duration-300" 
              style={{ width: `${(step / 3) * 100}%` }}
            ></div>
          </div>
        </div>

        {step === 1 && (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-gray-800">Upload Your Resume</h2>
            <p className="text-gray-600">
              Upload your resume or CV to help us analyze your skills and experience with AI.
            </p>
            
            <ResumeUploader onResumeProcessed={handleResumeProcessed} />

            <div className="mt-8">
              <h3 className="text-lg font-medium text-gray-800 mb-4">Or connect your LinkedIn profile</h3>
              <div className="flex items-center">
                <Linkedin className="h-6 w-6 text-blue-600 mr-2" />
                <input
                  type="text"
                  placeholder="LinkedIn Profile URL"
                  className="flex-grow border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={linkedinUrl}
                  onChange={(e) => setLinkedinUrl(e.target.value)}
                />
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-gray-800">Confirm Your Skills</h2>
            <p className="text-gray-600">
              Our AI has identified the following skills from your resume. Please confirm or modify them.
            </p>
            
            <div className="space-y-6">
              <SkillSelector
                categoryName="Technical Skills"
                skills={technicalSkills}
                selectedSkills={selectedTechnicalSkills}
                onToggleSkill={toggleTechnicalSkill}
              />
              
              <SkillSelector
                categoryName="Soft Skills"
                skills={softSkills}
                selectedSkills={selectedSoftSkills}
                onToggleSkill={toggleSoftSkill}
              />
              
              <SkillSelector
                categoryName="Professional Skills"
                skills={professionalSkills}
                selectedSkills={selectedProfessionalSkills}
                onToggleSkill={toggleProfessionalSkill}
              />
            </div>
            
            <div className="mt-4">
              <h3 className="text-lg font-medium text-gray-800 mb-2">Add Custom Skills</h3>
              <p className="text-gray-600 mb-4">
                If you have additional skills that weren't detected, you can add them here.
              </p>
              
              <div className="flex space-x-2">
                <input
                  type="text"
                  placeholder="Enter a skill"
                  className="flex-grow border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddCustomSkill()}
                />
                <select
                  className="border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={newSkillCategory}
                  onChange={(e) => setNewSkillCategory(e.target.value)}
                >
                  <option value="technical">Technical</option>
                  <option value="soft">Soft</option>
                  <option value="professional">Professional</option>
                </select>
                <button
                  className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors flex items-center"
                  onClick={handleAddCustomSkill}
                >
                  <Plus size={18} className="mr-1" /> Add
                </button>
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-gray-800">Set Your Career Goal</h2>
            <p className="text-gray-600">
              Select your target role or career path so we can analyze the skills gap and provide relevant recommendations.
            </p>
            
            <div className="space-y-4">
              <label className="block text-sm font-medium text-gray-700">
                Target Role
              </label>
              <select
                className="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                value={targetRole}
                onChange={(e) => setTargetRole(e.target.value)}
              >
                <option value="">Select a role</option>
                {jobRoles.map((role, index) => (
                  <option key={index} value={role}>{role}</option>
                ))}
              </select>
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Or specify a custom role
              </label>
              <input
                type="text"
                placeholder="e.g., AI Research Scientist"
                className="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                disabled={!!targetRole}
              />
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Experience Level
              </label>
              <div className="flex space-x-4">
                {['Entry Level', 'Mid Level', 'Senior', 'Executive'].map((level, index) => (
                  <button
                    key={index}
                    className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                      experienceLevel === level
                        ? 'bg-indigo-100 text-indigo-800 border border-indigo-300'
                        : 'bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200'
                    }`}
                    onClick={() => setExperienceLevel(level)}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="mt-8 flex justify-between">
          <button
            onClick={handleBack}
            className={`flex items-center px-4 py-2 rounded-md text-sm font-medium ${
              step === 1
                ? 'text-gray-400 cursor-not-allowed'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
            disabled={step === 1}
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back
          </button>
          
          <button
            onClick={handleNext}
            disabled={isSubmitting || (step === 3 && !targetRole)}
            className={`flex items-center px-6 py-2 bg-indigo-600 text-white rounded-md text-sm font-medium hover:bg-indigo-700 transition-colors ${
              isSubmitting || (step === 3 && !targetRole) ? 'opacity-70 cursor-not-allowed' : ''
            }`}
          >
            {isSubmitting ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </>
            ) : (
              <>
                {step === 3 ? 'Complete' : 'Next'}
                <ChevronRight className="h-4 w-4 ml-1" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};