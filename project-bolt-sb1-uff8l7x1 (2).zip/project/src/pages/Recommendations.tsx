import React, { useState, useEffect } from 'react';
import { Star, Clock, Filter, BookOpen, Award, DollarSign, BarChart2 } from 'lucide-react';
import { getRecommendedCourses } from '../services/skillMatcher';
import { aiSkillAnalysis, SkillMatch } from '../services/skillMatcher';

export const Recommendations: React.FC = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [priceFilter, setPriceFilter] = useState('all');
  const [durationFilter, setDurationFilter] = useState('all');
  const [showFilters, setShowFilters] = useState(false);
  const [targetRole, setTargetRole] = useState('Data Scientist');
  const [courses, setCourses] = useState<any[]>([]);
  const [skillMatch, setSkillMatch] = useState<SkillMatch | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadRecommendations = async () => {
      setIsLoading(true);
      try {
        // Get user skills from localStorage
        const storedSkills = localStorage.getItem('userSkills');
        let skills: { name: string; level: number }[] = [];
        
        if (storedSkills) {
          const parsedData = JSON.parse(storedSkills);
          
          // If we have stored target role, use it
          if (parsedData.targetRole) {
            setTargetRole(parsedData.targetRole);
          }
          
          // Combine all selected skills and assign estimated proficiency levels
          const allSkills = [
            ...parsedData.technical.map((skill: string) => ({ name: skill, level: Math.floor(Math.random() * 30) + 60 })), // Technical skills 60-90%
            ...parsedData.soft.map((skill: string) => ({ name: skill, level: Math.floor(Math.random() * 20) + 70 })), // Soft skills 70-90%
            ...parsedData.professional.map((skill: string) => ({ name: skill, level: Math.floor(Math.random() * 40) + 50 })) // Professional skills 50-90%
          ];
          
          skills = allSkills;
        } else {
          // Fallback to sample data if no stored skills
          skills = [
            { name: "Python", level: 85 },
            { name: "SQL", level: 75 },
            { name: "Data Analysis", level: 80 },
            { name: "Problem Solving", level: 90 },
            { name: "Machine Learning", level: 40 },
            { name: "Statistics", level: 50 },
            { name: "Data Visualization", level: 60 },
            { name: "Big Data Technologies", level: 30 },
            { name: "R", level: 72 },
            { name: "Statistical Analysis", level: 78 }
          ];
        }
        
        // Get skill match analysis
        const match = await aiSkillAnalysis(skills, targetRole);
        setSkillMatch(match);
        
        // Get recommended courses based on skill gaps
        const recommendedCourses = getRecommendedCourses(match, targetRole);
        setCourses(recommendedCourses);
      } catch (error) {
        console.error('Error loading recommendations:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadRecommendations();
  }, []);

  // Update recommendations when target role changes
  useEffect(() => {
    if (skillMatch) {
      const recommendedCourses = getRecommendedCourses(skillMatch, targetRole);
      setCourses(recommendedCourses);
    }
  }, [targetRole, skillMatch]);

  const filteredCourses = courses
    .filter(course => {
      if (activeTab === 'all') return true;
      return course.category === activeTab;
    })
    .filter(course => {
      if (priceFilter === 'all') return true;
      if (priceFilter === 'free') return course.price === 0;
      if (priceFilter === 'paid') return course.price > 0;
      if (priceFilter === 'under25') return course.discountPrice ? course.discountPrice < 25 : course.price < 25;
      return true;
    })
    .filter(course => {
      if (durationFilter === 'all') return true;
      const hours = parseInt(course.duration);
      if (durationFilter === 'short') return hours < 10;
      if (durationFilter === 'medium') return hours >= 10 && hours < 30;
      if (durationFilter === 'long') return hours >= 30;
      return true;
    });

  // Get unique categories from courses
  const categories = [...new Set(courses.map(course => course.category))];

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Recommended Courses</h1>
            <p className="text-gray-600">
              Personalized recommendations to help you bridge your skill gaps and reach your career goals.
            </p>
          </div>
          <div className="mt-4 md:mt-0 flex items-center space-x-4">
            <div className="flex flex-wrap gap-3">
              {['Data Scientist', 'Software Engineer', 'Product Manager', 'UX Designer'].map((role) => (
                <button
                  key={role}
                  onClick={() => setTargetRole(role)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    targetRole === role
                      ? 'bg-indigo-600 text-white'
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  {role}
                </button>
              ))}
            </div>
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center px-4 py-2 bg-gray-100 rounded-lg text-gray-700 hover:bg-gray-200 transition-colors"
            >
              <Filter className="mr-2" size={18} />
              Filter
            </button>
          </div>
        </div>

        {showFilters && (
          <div className="bg-gray-50 p-4 rounded-lg mb-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Price
                </label>
                <select
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={priceFilter}
                  onChange={(e) => setPriceFilter(e.target.value)}
                >
                  <option value="all">All Prices</option>
                  <option value="free">Free</option>
                  <option value="paid">Paid</option>
                  <option value="under25">Under $25</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Duration
                </label>
                <select
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  value={durationFilter}
                  onChange={(e) => setDurationFilter(e.target.value)}
                >
                  <option value="all">All Durations</option>
                  <option value="short">Short (&lt; 10 hours)</option>
                  <option value="medium">Medium (10-30 hours)</option>
                  <option value="long">Long (&gt; 30 hours)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Level
                </label>
                <select
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">All Levels</option>
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Category Tabs */}
        <div className="mb-6 border-b border-gray-200">
          <div className="flex overflow-x-auto space-x-4 pb-2">
            <button
              className={`px-4 py-2 font-medium text-sm rounded-t-lg ${
                activeTab === 'all'
                  ? 'bg-indigo-600 text-white'
                  : 'text-gray-600 hover:text-indigo-600'
              }`}
              onClick={() => setActiveTab('all')}
            >
              All Recommendations
            </button>
            {categories.map((category) => (
              <button
                key={category}
                className={`px-4 py-2 font-medium text-sm rounded-t-lg ${
                  activeTab === category
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-600 hover:text-indigo-600'
                }`}
                onClick={() => setActiveTab(category)}
              >
                {category.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
              </button>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        ) : (
          <>
            {/* Course Cards */}
            {filteredCourses.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredCourses.map((course) => (
                  <div key={course.id} className="border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                    <div className="relative">
                      <img 
                        src={course.image} 
                        alt={course.title} 
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-2 right-2 bg-indigo-600 text-white px-2 py-1 rounded-md text-sm font-semibold">
                        {course.customMatchScore ? Math.min(Math.round(course.customMatchScore), 100) : course.matchScore}% Match
                      </div>
                      {course.provider && (
                        <div className="absolute bottom-2 left-2 bg-white px-2 py-1 rounded-md text-xs font-medium">
                          {course.provider}
                        </div>
                      )}
                    </div>
                    
                    <div className="p-4">
                      <h3 className="text-lg font-semibold text-gray-800 mb-2">{course.title}</h3>
                      
                      <p className="text-sm text-gray-600 mb-3">
                        {course.instructor}
                      </p>
                      
                      <div className="flex items-center mb-3">
                        <div className="flex items-center mr-2">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="ml-1 text-sm font-medium">{course.rating}</span>
                        </div>
                        <span className="text-xs text-gray-500">({course.reviews.toLocaleString()} reviews)</span>
                      </div>
                      
                      <div className="flex flex-wrap gap-2 mb-3">
                        {course.skills.slice(0, 3).map((skill: string, index: number) => (
                          <span 
                            key={index} 
                            className="bg-indigo-50 text-indigo-700 px-2 py-1 rounded-md text-xs font-medium"
                          >
                            {skill}
                          </span>
                        ))}
                        {course.skills.length > 3 && (
                          <span className="bg-gray-50 text-gray-700 px-2 py-1 rounded-md text-xs font-medium">
                            +{course.skills.length - 3} more
                          </span>
                        )}
                      </div>
                      
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center text-sm text-gray-600">
                          <Clock className="h-4 w-4 mr-1" />
                          {course.duration}
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <Award className="h-4 w-4 mr-1" />
                          {course.level}
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div>
                          {course.discount ? (
                            <div className="flex items-center">
                              <span className="text-lg font-bold text-gray-800">${course.discountPrice}</span>
                              <span className="ml-2 text-sm text-gray-500 line-through">${course.price}</span>
                            </div>
                          ) : (
                            <span className="text-lg font-bold text-gray-800">${course.price}</span>
                          )}
                        </div>
                        <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors">
                          View Course
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-600">No courses match your current filters. Try adjusting your filters or selecting a different role.</p>
              </div>
            )}
          </>
        )}
      </div>

      {/* Learning Path Section */}
      {skillMatch && (
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <h2 className="text-xl font t-semibold text-gray-800 mb-6">Your Recommended Learning Path</h2>
          
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-1 bg-indigo-200"></div>
            
            <div className="space-y-8">
              {filteredCourses.slice(0, 5).map((course, index) => (
                <div key={course.id} className="relative flex items-start">
                  <div className={`absolute left-8 top-2 w-4 h-4 rounded-full ${index < 3 ? 'bg-indigo-600' : 'bg-gray-300'} transform -translate-x-1/2 z-10`}></div>
                  <div className="pl-16">
                    <h3 className="text-lg font-medium text-gray-800">Step {index + 1}: {index === 0 ? 'Build Foundation in' : index === 1 ? 'Develop Skills in' : index === 2 ? 'Master' : 'Advance to'} {course.skills[0]}</h3>
                    <p className="text-gray-600 mt-1 mb-3">
                      {index === 0 
                        ? `Start with ${course.skills[0]} fundamentals to build a solid foundation for ${targetRole}.` 
                        : index === 1 
                        ? `Develop practical skills in ${course.skills[0]} to strengthen your capabilities.`
                        : index === 2
                        ? `Master advanced concepts in ${course.skills[0]} to stand out in the job market.`
                        : `Further specialize in ${course.skills[0]} to become an expert in your field.`}
                    </p>
                    <div className={`${index < 3 ? 'bg-indigo-50' : 'bg-gray-50'} p-3 rounded-lg ${index >= 3 ? 'border border-gray-200' : ''}`}>
                      <div className="flex items-center">
                        <div className="flex-shrink-0 mr-3">
                          <BookOpen className={`h-8 w-8 ${index < 3 ? 'text-indigo-500' : 'text-gray-400'}`} />
                        </div>
                        <div>
                          <h4 className={`font-medium ${index < 3 ? 'text-indigo-800' : 'text-gray-700'}`}>{course.title}</h4>
                          <p className={`text-sm ${index < 3 ? 'text-indigo-600' : 'text-gray-500'}`}>{course.duration} • {course.level}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Skills Progress Section */}
      {skillMatch && (
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
            <BarChart2 className="mr-2 text-indigo-600" size={20} />
            Projected Skill Growth
          </h2>
          
          <p className="text-gray-600 mb-6">
            Here's how your skills will improve after completing the recommended courses.
          </p>
          
          <div className="space-y-6">
            {skillMatch.gaps.slice(0, 3).map((gap, index) => (
              <div key={index}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">{gap.name}</span>
                  <div className="text-sm font-medium text-gray-700">
                    <span className="text-amber-500">{gap.currentLevel}%</span> → <span className="text-green-500">{gap.requiredLevel}%</span>
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5 relative">
                  <div className="bg-amber-500 h-2.5 rounded-full" style={{ width: `${gap.currentLevel}%` }}></div>
                  <div className="absolute top-0 left-0 bg-green-500 h-2.5 rounded-full opacity-50" style={{ width: `${gap.requiredLevel}%` }}></div>
                </div>
              </div>
            ))}
            
            {skillMatch.missing.slice(0, 2).map((skill, index) => (
              <div key={`missing-${index}`}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">{skill.name}</span>
                  <div className="text-sm font-medium text-gray-700">
                    <span className="text-red-500">0%</span> → <span className="text-green-500">{skill.requiredLevel}%</span>
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5 relative">
                  <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '0%' }}></div>
                  <div className="absolute top-0 left-0 bg-green-500 h-2.5 rounded-full opacity-50" style={{ width: `${skill.requiredLevel}%` }}></div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-8 p-4 bg-indigo-50 rounded-lg border border-indigo-100">
            <div className="flex items-start">
              <DollarSign className="flex-shrink-0 h-5 w-5 text-indigo-600 mt-0.5 mr-2" />
              <div>
                <h3 className="font-medium text-indigo-800">Investment Summary</h3>
                <p className="text-sm text-indigo-700 mt-1">
                  Estimated total investment: <span className="font-semibold">${filteredCourses.reduce((sum, course) => sum + (course.discountPrice || course.price), 0).toFixed(2)}</span> • 
                  Estimated time: <span className="font-semibold">{filteredCourses.reduce((sum, course) => sum + parseInt(course.duration), 0)} hours</span>
                </p>
                <p className="text-sm text-indigo-700 mt-1">
                  Average salary increase after completion: <span className="font-semibold">$15,000 - $25,000</span> annually
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};