import React, { useState, useEffect } from 'react';
import { ArrowRight, CheckCircle, XCircle, AlertCircle, Loader } from 'lucide-react';
import { SkillGapVisualizer } from '../components/analysis/SkillGapVisualizer';
import { aiSkillAnalysis, SkillMatch } from '../services/skillMatcher';

interface SkillAnalysisProps {
  onViewRecommendations: () => void;
}

export const SkillAnalysis: React.FC<SkillAnalysisProps> = ({ onViewRecommendations }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [skillMatch, setSkillMatch] = useState<SkillMatch | null>(null);
  const [targetRole, setTargetRole] = useState<string>('Data Scientist');
  const [userSkills, setUserSkills] = useState<{ name: string; level: number }[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get user skills from localStorage
        const storedSkills = localStorage.getItem('userSkills');
        let skills: { name: string; level: number }[] = [];
        
        if (storedSkills) {
          const parsedData = JSON.parse(storedSkills);
          
          // If we have stored target role, use it
          if (parsedData.targetRole) {
            setTargetRole(parsedData.targetRole);
          }
          
          // Combine all selected skills and assign estimated proficiency levels
          const allSkills = [
            ...parsedData.technical.map((skill: string) => ({ name: skill, level: Math.floor(Math.random() * 30) + 60 })), // Technical skills 60-90%
            ...parsedData.soft.map((skill: string) => ({ name: skill, level: Math.floor(Math.random() * 20) + 70 })), // Soft skills 70-90%
            ...parsedData.professional.map((skill: string) => ({ name: skill, level: Math.floor(Math.random() * 40) + 50 })) // Professional skills 50-90%
          ];
          
          skills = allSkills;
          setUserSkills(allSkills);
        } else {
          // Fallback to sample data if no stored skills
          skills = [
            { name: "Python", level: 85 },
            { name: "SQL", level: 75 },
            { name: "Data Analysis", level: 80 },
            { name: "Problem Solving", level: 90 },
            { name: "Machine Learning", level: 40 },
            { name: "Statistics", level: 50 },
            { name: "Data Visualization", level: 60 },
            { name: "Big Data Technologies", level: 30 },
            { name: "R", level: 72 },
            { name: "Statistical Analysis", level: 78 }
          ];
          setUserSkills(skills);
        }
        
        // Use AI to analyze skills
        const matchResult = await aiSkillAnalysis(skills, targetRole);
        setSkillMatch(matchResult);
      } catch (error) {
        console.error('Error fetching skill analysis:', error);
        setError('Failed to load skill analysis. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);

  // Update analysis when target role changes
  useEffect(() => {
    const updateAnalysis = async () => {
      if (userSkills.length === 0) return;
      
      setIsLoading(true);
      try {
        const matchResult = await aiSkillAnalysis(userSkills, targetRole);
        setSkillMatch(matchResult);
      } catch (error) {
        console.error('Error updating skill analysis:', error);
        setError('Failed to update skill analysis. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };
    
    updateAnalysis();
  }, [targetRole, userSkills]);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-6xl flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <Loader className="h-12 w-12 text-indigo-600 animate-spin mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Analyzing Your Skills</h2>
          <p className="text-gray-600">
            Our AI is comparing your skills with the requirements for your target role.
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        <div className="bg-red-50 p-6 rounded-xl border border-red-200 text-center">
          <XCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Error Loading Analysis</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  if (!skillMatch) {
    return null;
  }

  const { overallMatch, strengths, gaps, missing } = skillMatch;

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Skill Analysis</h1>
            <p className="text-gray-600">
              Here's how your current skills match with your target role: <span className="font-semibold">{targetRole}</span>
            </p>
          </div>
          <div className="mt-4 md:mt-0 flex items-center">
            <div className="mr-4">
              <div className="text-3xl font-bold text-indigo-600">{overallMatch}%</div>
              <div className="text-sm text-gray-500">Overall Match</div>
            </div>
            <div className="w-24 h-24 relative">
              <svg className="w-full h-full" viewBox="0 0 36 36">
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="#E5E7EB"
                  strokeWidth="3"
                  strokeDasharray="100, 100"
                />
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="#4F46E5"
                  strokeWidth="3"
                  strokeDasharray={`${overallMatch}, 100`}
                />
              </svg>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-800">Target Role Selection</h2>
          </div>
          <div className="flex flex-wrap gap-3">
            {['Data Scientist', 'Software Engineer', 'Product Manager', 'UX Designer'].map((role) => (
              <button
                key={role}
                onClick={() => setTargetRole(role)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  targetRole === role
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
              >
                {role}
              </button>
            ))}
          </div>
        </div>

        <SkillGapVisualizer 
          strengths={strengths}
          gaps={gaps}
          missing={missing}
        />
      </div>

      {/* Career Path Visualization */}
      <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-6">Your Career Path</h2>
        
        <div className="relative">
          <div className="absolute left-8 top-0 bottom-0 w-1 bg-gray-200"></div>
          
          <div className="space-y-8">
            <div className="relative flex items-start">
              <div className="absolute left-8 top-2 w-4 h-4 rounded-full bg-green-500 transform -translate-x-1/2"></div>
              <div className="pl-16">
                <h3 className="text-lg font-medium text-gray-800">Current: {targetRole === 'Data Scientist' ? 'Data Analyst' : 
                                                                           targetRole === 'Software Engineer' ? 'Junior Developer' :
                                                                           targetRole === 'Product Manager' ? 'Business Analyst' :
                                                                           'UI Designer'}</h3>
                <p className="text-gray-600 mt-1">You have a solid foundation in {targetRole === 'Data Scientist' ? 'data analysis and basic programming' : 
                                                                                 targetRole === 'Software Engineer' ? 'programming and development' :
                                                                                 targetRole === 'Product Manager' ? 'business analysis and project coordination' :
                                                                                 'UI design and basic user research'}.</p>
              </div>
            </div>
            
            <div className="relative flex items-start">
              <div className="absolute left-8 top-2 w-4 h-4 rounded-full bg-amber-500 transform -translate-x-1/2"></div>
              <div className="pl-16">
                <h3 className="text-lg font-medium text-gray-800">Next: Junior {targetRole}</h3>
                <p className="text-gray-600 mt-1">Focus on building {targetRole === 'Data Scientist' ? 'machine learning and statistical skills' : 
                                                                    targetRole === 'Software Engineer' ? 'advanced programming and system design skills' :
                                                                    targetRole === 'Product Manager' ? 'product strategy and stakeholder management skills' :
                                                                    'UX research and interaction design skills'}.</p>
              </div>
            </div>
            
            <div className="relative flex items-start">
              <div className="absolute left-8 top-2 w-4 h-4 rounded-full bg-gray-300 transform -translate-x-1/2"></div>
              <div className="pl-16">
                <h3 className="text-lg font-medium text-gray-800">Target: {targetRole}</h3>
                <p className="text-gray-600 mt-1">Develop expertise in {targetRole === 'Data Scientist' ? 'advanced ML techniques and big data technologies' : 
                                                                       targetRole === 'Software Engineer' ? 'architecture design and advanced frameworks' :
                                                                       targetRole === 'Product Manager' ? 'product lifecycle management and market analysis' :
                                                                       'end-to-end UX design and user testing methodologies'}.</p>
              </div>
            </div>
            
            <div className="relative flex items-start">
              <div className="absolute left-8 top-2 w-4 h-4 rounded-full bg-gray-300 transform -translate-x-1/2"></div>
              <div className="pl-16">
                <h3 className="text-lg font-medium text-gray-800">Future: Senior {targetRole}</h3>
                <p className="text-gray-600 mt-1">Lead projects and develop specialized expertise in your domain.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Insights Section */}
      <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-6">AI-Generated Insights</h2>
        
        <div className="space-y-6">
          <div className="bg-indigo-50 p-6 rounded-lg border border-indigo-100">
            <h3 className="text-lg font-medium text-indigo-800 mb-3">Skill Analysis Summary</h3>
            <p className="text-indigo-700">
              {targetRole === 'Data Scientist' && 
                `Your profile shows strong technical skills in Python and SQL, with excellent soft skills in problem-solving. 
                To become a Data Scientist, focus on developing your machine learning expertise and statistical knowledge, 
                which are currently your biggest skill gaps. Your data analysis background provides a solid foundation to build upon.`}
              
              {targetRole === 'Software Engineer' && 
                `Your profile shows some programming skills, but you'll need to develop expertise in JavaScript, React, and other 
                web technologies to become a Software Engineer. Your problem-solving skills are strong, which is a great foundation. 
                Focus on building your technical stack and gaining experience with modern development workflows.`}
              
              {targetRole === 'Product Manager' && 
                `Your analytical skills provide a good foundation, but to become a Product Manager, you'll need to develop 
                product strategy, market research, and stakeholder management skills. Focus on understanding user needs, 
                product lifecycle management, and improving your communication skills.`}
              
              {targetRole === 'UX Designer' && 
                `Your current skills show some design aptitude, but to become a UX Designer, you'll need to develop expertise 
                in user research, wireframing, and prototyping. Focus on building a strong portfolio of user-centered design 
                work and developing empathy for user needs.`}
            </p>
          </div>
          
          <div className="bg-green-50 p-6 rounded-lg border border-green-100">
            <h3 className="text-lg font-medium text-green-800 mb-3">Your Strengths</h3>
            <p className="text-green-700 mb-3">
              {strengths.length > 0 ? 
                `Your strongest skills align well with the ${targetRole} role. ${strengths[0].name} (${strengths[0].level}%) 
                is particularly valuable and transferable to your target role.` :
                `You don't have any skills that meet the requirements for a ${targetRole} yet, but don't worry! 
                With focused learning, you can develop the necessary skills.`}
            </p>
            {strengths.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {strengths.slice(0, 2).map((strength, index) => (
                  <div key={index} className="bg-white p-3 rounded border border-green-200">
                    <span className="font-medium text-green-800">{strength.name} ({strength.level}%)</span>
                    <p className="text-sm text-green-600">Excellent foundation for {targetRole} work</p>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div className="bg-amber-50 p-6 rounded-lg border border-amber-100">
            <h3 className="text-lg font-medium text-amber-800 mb-3">Development Priorities</h3>
            <p className="text-amber-700 mb-3">
              Based on your skill gaps, here are the key areas to focus on for maximum impact:
            </p>
            <ol className="list-decimal list-inside space-y-2 text-amber-700">
              {gaps.slice(0, 2).map((gap, index) => (
                <li key={index}><span className="font-medium">{gap.name} ({gap.gap}% gap)</span> - {index === 0 ? 'This is the most critical skill to develop' : 'Important for your target role'}</li>
              ))}
              {missing.slice(0, 2).map((skill, index) => (
                <li key={`missing-${index}`}><span className="font-medium">{skill.name}</span> - You need to develop this skill from scratch</li>
              ))}
            </ol>
          </div>
          
          <div className="bg-blue-50 p-6 rounded-lg border border-blue-100">
            <h3 className="text-lg font-medium text-blue-800 mb-3">Industry Insights</h3>
            <p className="text-blue-700">
              {targetRole === 'Data Scientist' && 
                `The data science field is evolving rapidly, with increasing emphasis on specialized ML knowledge and cloud-based 
                big data processing. Your current skill set is most aligned with Data Analyst roles (85% match), but with focused 
                learning in the recommended areas, you can bridge the gap to Data Scientist (currently ${overallMatch}% match) within 6-9 months 
                of dedicated study.`}
              
              {targetRole === 'Software Engineer' && 
                `The software engineering field values both breadth and depth of technical knowledge. Modern web development 
                requires expertise in JavaScript frameworks, API design, and DevOps practices. With focused learning in these areas, 
                you can improve your current match (${overallMatch}%) and become a competitive candidate within 8-12 months.`}
              
              {targetRole === 'Product Manager' && 
                `Product management requires a blend of business acumen, technical understanding, and strong interpersonal skills. 
                Companies are increasingly looking for product managers who can work with data and understand user needs deeply. 
                With your current match (${overallMatch}%), focused development in product strategy and user research could prepare you 
                for a junior role within 6 months.`}
              
              {targetRole === 'UX Designer' && 
                `UX design has become increasingly specialized, with companies valuing designers who can conduct research, 
                create prototypes, and validate designs through testing. Your current match (${overallMatch}%) suggests you'll need 
                to develop a strong portfolio demonstrating these skills to be competitive in the job market.`}
            </p>
          </div>
        </div>
      </div>

      {/* Next Steps */}
      <div className="bg-indigo-700 rounded-xl shadow-lg p-8 text-white">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div>
            <h2 className="text-xl font-semibold mb-2">Ready to bridge your skill gaps?</h2>
            <p className="text-indigo-100">
              We've prepared personalized course recommendations to help you reach your career goals.
            </p>
          </div>
          <button 
            onClick={onViewRecommendations}
            className="mt-4 md:mt-0 bg-white text-indigo-700 px-6 py-3 rounded-lg font-semibold text-lg flex items-center hover:bg-indigo-50 transition-colors"
          >
            View Recommendations <ArrowRight className="ml-2" size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};