/*
  # Initial Schema Setup for Career Guidance Platform

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key)
      - `created_at` (timestamp)
      - `email` (text, unique)
      - `full_name` (text)
      - `resume_text` (text)
      - `linkedin_url` (text)
      - `target_role` (text)
    - `skills`
      - `id` (uuid, primary key)
      - `created_at` (timestamp)
      - `profile_id` (uuid, foreign key)
      - `name` (text)
      - `category` (text)
      - `level` (integer)
    - `job_roles`
      - `id` (uuid, primary key)
      - `created_at` (timestamp)
      - `title` (text)
      - `description` (text)
    - `role_skills`
      - `id` (uuid, primary key)
      - `created_at` (timestamp)
      - `role_id` (uuid, foreign key)
      - `skill_name` (text)
      - `category` (text)
      - `required_level` (integer)
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  email text UNIQUE NOT NULL,
  full_name text,
  resume_text text,
  linkedin_url text,
  target_role text
);

-- Create skills table
CREATE TABLE IF NOT EXISTS skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  profile_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  category text NOT NULL,
  level integer NOT NULL
);

-- Create job_roles table
CREATE TABLE IF NOT EXISTS job_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  title text UNIQUE NOT NULL,
  description text
);

-- Create role_skills table
CREATE TABLE IF NOT EXISTS role_skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  role_id uuid REFERENCES job_roles(id) ON DELETE CASCADE,
  skill_name text NOT NULL,
  category text NOT NULL,
  required_level integer NOT NULL
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_skills ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
CREATE POLICY "Users can read own profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profiles"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profiles"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Create policies for skills
CREATE POLICY "Users can read own skills"
  ON skills
  FOR SELECT
  TO authenticated
  USING (profile_id IN (SELECT id FROM profiles WHERE id = auth.uid()));

CREATE POLICY "Users can insert own skills"
  ON skills
  FOR INSERT
  TO authenticated
  WITH CHECK (profile_id IN (SELECT id FROM profiles WHERE id = auth.uid()));

CREATE POLICY "Users can update own skills"
  ON skills
  FOR UPDATE
  TO authenticated
  USING (profile_id IN (SELECT id FROM profiles WHERE id = auth.uid()));

-- Create policies for job_roles (public read)
CREATE POLICY "Anyone can read job roles"
  ON job_roles
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Create policies for role_skills (public read)
CREATE POLICY "Anyone can read role skills"
  ON role_skills
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Insert sample job roles and required skills
INSERT INTO job_roles (title, description)
VALUES 
  ('Data Scientist', 'Analyzes and interprets complex data to help organizations make better decisions'),
  ('Software Engineer', 'Designs, develops, and maintains software systems'),
  ('Product Manager', 'Oversees product development from conception to launch'),
  ('UX Designer', 'Creates user-friendly interfaces and experiences for digital products')
ON CONFLICT (title) DO NOTHING;

-- Insert sample role skills for Data Scientist
DO $$
DECLARE
  data_scientist_id uuid;
BEGIN
  SELECT id INTO data_scientist_id FROM job_roles WHERE title = 'Data Scientist';
  
  INSERT INTO role_skills (role_id, skill_name, category, required_level)
  VALUES
    (data_scientist_id, 'Python', 'Technical', 80),
    (data_scientist_id, 'Machine Learning', 'Technical', 75),
    (data_scientist_id, 'Statistics', 'Technical', 85),
    (data_scientist_id, 'SQL', 'Technical', 70),
    (data_scientist_id, 'Data Visualization', 'Technical', 75),
    (data_scientist_id, 'Big Data Technologies', 'Technical', 65),
    (data_scientist_id, 'Deep Learning', 'Technical', 60),
    (data_scientist_id, 'Problem Solving', 'Soft', 90),
    (data_scientist_id, 'Communication', 'Soft', 80),
    (data_scientist_id, 'Teamwork', 'Soft', 75),
    (data_scientist_id, 'Data Analysis', 'Professional', 90),
    (data_scientist_id, 'Research', 'Professional', 80),
    (data_scientist_id, 'Project Management', 'Professional', 60);
END $$;

-- Insert sample role skills for Software Engineer
DO $$
DECLARE
  software_engineer_id uuid;
BEGIN
  SELECT id INTO software_engineer_id FROM job_roles WHERE title = 'Software Engineer';
  
  INSERT INTO role_skills (role_id, skill_name, category, required_level)
  VALUES
    (software_engineer_id, 'JavaScript', 'Technical', 85),
    (software_engineer_id, 'React', 'Technical', 80),
    (software_engineer_id, 'Node.js', 'Technical', 75),
    (software_engineer_id, 'TypeScript', 'Technical', 70),
    (software_engineer_id, 'Git', 'Technical', 80),
    (software_engineer_id, 'Database Design', 'Technical', 70),
    (software_engineer_id, 'System Architecture', 'Technical', 65),
    (software_engineer_id, 'Problem Solving', 'Soft', 90),
    (software_engineer_id, 'Communication', 'Soft', 75),
    (software_engineer_id, 'Teamwork', 'Soft', 85),
    (software_engineer_id, 'Code Review', 'Professional', 80),
    (software_engineer_id, 'Agile Methodologies', 'Professional', 75),
    (software_engineer_id, 'Testing', 'Professional', 80);
END $$;